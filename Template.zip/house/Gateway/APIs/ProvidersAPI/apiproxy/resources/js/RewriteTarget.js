//Rewrite the target uri to map product list

//Rewrite the target uri to map product list
flow.setVariable("target.url","http://www.google.com/ig/api?stock=ESPN");
