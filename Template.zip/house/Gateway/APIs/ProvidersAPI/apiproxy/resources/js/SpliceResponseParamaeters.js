if (flow.getVariable("api.product.name")=="Basic")
	{
	flow.setVariable("spliceVariables","results");
	}
else
	{
	flow.setVariable("spliceVariables","status");
	}
